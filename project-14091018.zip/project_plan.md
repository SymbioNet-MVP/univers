# UniverS — International Study Partner Matching

## 1. Project Description
UniverS ist eine internationale Plattform, die Lernende weltweit in unter 3 Minuten mit einem
relevanten Lernpartner verbindet. Kernmetrik: **Weekly Matched Conversations**.

Zielgruppe (international, nicht .edu-zentriert):
- Schüler:innen (School)
- Studierende (University)
- Austauschstudierende
- Alumni
- Mentor:innen

Positionierung: Kein klassisches Uni-Portal, kein generisches Social Network. Vertrauenswürdig,
akademisch, modern, international. Referenzgefühl: Linear, Notion, Discord, Duolingo.

Grundsatzentscheidung: **Aufbau direkt auf eigener Supabase (SaaS Supabase)**, damit Auth,
Profile, Matching, Chat und Community später ohne Migration skalieren. Keine Demo-Daten,
kein Readdy-internes Backend.

## 2. Page Structure
- `/` — Redirect zur erkannten Sprache
- `/en` — Landing Page (Englisch, Default)
- `/de` — Landing Page (Deutsch)
- `/login` — Anmeldung
- `/signup` — Registrierung
- `/onboarding` — Kurzes Onboarding (max. 3 Minuten)
- `/dashboard` — Startseite nach Login, niemals leer (Match-Vorschläge)
- `/profile/:id` — Profil
- `/matches` — Matching-Übersicht / Match-Requests
- `/chat` — Chat-Übersicht
- `/chat/:conversationId` — 1:1 Chat
- `/community` — Mini Community (Posts + Kommentare)
- `/community/:postId` — Post-Detail
- `/insights` — Founder-Insights (Aktivierungs-Funnel, nur für Founder sichtbar)
- `/imprint` — Impressum / Legal Notice (EN/DE)
- `/privacy` — Datenschutzerklärung / Privacy Policy (EN/DE)

## 3. Core Features (PHASE 1 — MVP)
- [ ] Landing Page
- [ ] Auth (Supabase Auth: E-Mail + Passwort, optional Google)
- [ ] Onboarding (kurz: Name, Land, Institution, Fachbereich, Bildungsniveau, Sprache, Zeitzone; optional Interessen/Skills/Ziele)
- [ ] Profile
- [ ] Institution Verification (global: Institution + Domain)
- [ ] Matching (Vorschläge auf Basis von Fachbereich, Niveau, Sprache, Zeitzone, Zielen)
- [ ] Match Requests (Anfrage senden / annehmen / ablehnen)
- [ ] 1:1 Chat (Text)
- [ ] Mini Community (Posts + Kommentare)
- [x] Zweisprachige Landing Page (EN Default + DE) mit Sprachumschalter und lokalisierten Routen `/en` `/de`
- [x] Invite-a-Study-Partner-System (Referral-Link, Copy/Share, Statistiken, Badges, Beitritts-Tracking)

### Ausdrücklich NICHT in Phase 1
- AI Tutor, Karrierebereich, Jobbörse, Zertifikate, Kurse, Payments, Video Calls,
  komplexe Gruppenverwaltung, Mentor-Marktplatz, Study Groups.

## 4. Data Model Design (Supabase / PostgreSQL)

### Table: profiles
| Field | Type | Description |
|-------|------|-------------|
| id | uuid (PK, = auth.users.id) | Nutzer-ID |
| full_name | text | Name |
| avatar_url | text | Profilbild |
| country | text | Land (ISO) |
| institution_id | uuid (FK institutions) | Institution |
| field_of_study | text | Fachbereich |
| education_level | text | School / University / Exchange / Alumni / Mentor |
| languages | text[] | Sprachen |
| timezone | text | Zeitzone |
| interests | text[] | Interessen (optional) |
| skills | text[] | Skills (optional) |
| goals | text[] | Lernziele (optional) |
| onboarding_completed | boolean | Onboarding abgeschlossen |
| created_at / updated_at | timestamptz | Zeitstempel |

### Table: institutions
| Field | Type | Description |
|-------|------|-------------|
| id | uuid (PK) | Institution-ID |
| name | text | Name |
| country | text | Land |
| domain | text (unique) | E-Mail-Domain |
| type | text | School / University / Academy / Learning Organization |
| verified | boolean | Verifiziert |
| created_at | timestamptz | Zeitstempel |

### Table: user_verifications
| Field | Type | Description |
|-------|------|-------------|
| id | uuid (PK) | |
| user_id | uuid (FK profiles) | Nutzer |
| institution_id | uuid (FK institutions) | Institution |
| email_domain | text | Geprüfte Domain |
| status | text | pending / verified / rejected |
| verified_at | timestamptz | |

### Table: match_requests
| Field | Type | Description |
|-------|------|-------------|
| id | uuid (PK) | |
| sender_id | uuid (FK profiles) | Sender |
| receiver_id | uuid (FK profiles) | Empfänger |
| message | text | Kurze Nachricht |
| status | text | pending / accepted / declined |
| created_at / updated_at | timestamptz | |

### Table: matches
| Field | Type | Description |
|-------|------|-------------|
| id | uuid (PK) | |
| user_a | uuid (FK profiles) | |
| user_b | uuid (FK profiles) | |
| created_at | timestamptz | Nach Annahme |

### Table: conversations
| Field | Type | Description |
|-------|------|-------------|
| id | uuid (PK) | |
| match_id | uuid (FK matches) | |
| last_message_at | timestamptz | |

### Table: messages
| Field | Type | Description |
|-------|------|-------------|
| id | uuid (PK) | |
| conversation_id | uuid (FK conversations) | |
| sender_id | uuid (FK profiles) | |
| content | text | Nachricht |
| created_at | timestamptz | |

### Table: community_posts
| Field | Type | Description |
|-------|------|-------------|
| id | uuid (PK) | |
| author_id | uuid (FK profiles) | |
| type | text | Question / Study Goal / Looking for Buddy / Resource Share |
| title | text | |
| body | text | |
| created_at | timestamptz | |

### Table: community_comments
| Field | Type | Description |
|-------|------|-------------|
| id | uuid (PK) | |
| post_id | uuid (FK community_posts) | |
| author_id | uuid (FK profiles) | |
| body | text | |
| created_at | timestamptz | |

### Table: invites
| Field | Type | Description |
|-------|------|-------------|
| id | uuid (PK) | |
| inviter_id | uuid (FK profiles) | Einladende Person |
| code | text | Referral-Code |
| invited_email | text | Optional vorab eingeladene E-Mail |
| visitor_id | text | Anonyme Besucher-ID (Attribution) |
| invitee_id | uuid (FK profiles) | Beigetretene Person |
| status | text | pending / joined |
| created_at / joined_at | timestamptz | |

Zusätzlich auf `profiles`: `referral_code` (auto via Trigger), `referred_by` (FK profiles),
`is_founder` (bool, nur Founder sehen die Insights-Seite).
Invite-RPCs: `register_invite_visit(p_code, p_visitor)`, `redeem_invite(p_code, p_visitor)`.

### Table: analytics_events
| Field | Type | Description |
|-------|------|-------------|
| id | uuid (PK) | |
| user_id | uuid (FK profiles, nullable) | Angemeldete Person (falls vorhanden) |
| anonymous_id | text | Anonyme Besucher-ID (Attribution vor Login) |
| event_name | text | Funnel-Event (z. B. `signup_completed`) |
| props | jsonb | Zusatz-Kontext |
| locale | text | Sprache zum Zeitpunkt des Events |
| created_at | timestamptz | Zeitstempel |

Insert-only für `anon`/`authenticated` (kein SELECT für Clients). Auswertung ausschließlich über die
SECURITY-DEFINER-Funktion `get_founder_insights()`, die nur `profiles.is_founder = true` zulässt.
Die erste registrierte Person wird per Trigger (`mark_first_founder`) automatisch Founder.
Zusätzlich liefert `get_founder_insights()` eine `campus`-Auswertung (Lernende / Matches /
Gespräche / aktive Lernende je Institution).

### Table: email_log
| Field | Type | Description |
|-------|------|-------------|
| id | uuid (PK) | |
| user_id | uuid | Empfänger |
| email_type | text | welcome / match_request / match_accepted / new_message / weekly_match_digest |
| ref_id | text | Dedupe-Schlüssel (z. B. Request-ID, Conversation-Woche) |
| locale | text | Sprache der E-Mail |
| resend_id | text | Resend-Message-ID |
| status | text | sent / failed |
| error | text | Fehlermeldung (falls fehlgeschlagen) |
| created_at | timestamptz | Zeitstempel |

Kein RLS-Policy für Clients — ausschließlich der Service Role (Edge Functions) liest/schreibt.
Unique-Index `(user_id, email_type, coalesce(ref_id, ''))` verhindert Doppelversand.

### RLS-Policy-Konzept (grob)
- profiles: jeder kann öffentliche Felder lesen; nur eigene Zeile schreiben/ändern.
- institutions: öffentlich lesbar; Schreiben nur über Admin/Seed/Edge Function.
- user_verifications: nur eigene Zeile lesen/schreiben.
- match_requests: sichtbar für sender oder receiver; nur sender erstellt.
- matches/conversations/messages: nur Beteiligte lesen/schreiben.
- community_posts/comments: öffentlich (angemeldet) lesbar; Autor:in schreibt/ändert eigene.
- invites: nur die einladende Person liest/schreibt eigene Zeilen; Beitritt ausschließlich über RPC.
- analytics_events: nur INSERT (anon + authenticated), kein SELECT für Clients; Auswertung nur via `get_founder_insights()`.

## 5. Backend / Third-party Integration Plan
- Database / Auth / Storage: **SaaS Supabase (eigene Instanz)** — Verbindung zuerst herstellen.
- Realtime (Chat): Supabase Realtime.
- Shopify: nicht benötigt.
- Stripe / Payments: nicht in Phase 1.
- Resend: produktiv seit Phase 9. Transaktionale E-Mails (Welcome, Match-Anfrage, Match angenommen, neue Nachricht, wöchentliche Match-Empfehlung) über die Edge Functions `send-transactional-email` und `weekly-match-digest`. Secrets `RESEND_API_KEY` und `RESEND_FROM_DOMAIN` liegen in den Supabase Edge Function Secrets.
- Form: Waitlist-Formular auf der Landing Page (bereits eingebunden).

## 6. Development Phase Plan

### Phase 0: Foundation (aktuell)
- Goal: Grundgerüst, damit alles sauber aufsetzt.
- Deliverable: project_plan.md, Design-System (Tokens/Fonts), vollständige Landing Page,
  Supabase-Verbindung herstellen.

### Phase 1: Datenbank & Auth
- Goal: Reales Datenmodell + Anmeldung.
- Deliverable: Supabase Schema (alle Tabellen), RLS-Policies, Auth-Architektur,
  Login-/Signup-Seiten, Session-Handling, geschützte Routen.

### Phase 2: Onboarding & Profile
- Goal: Nutzer in < 3 Minuten startklar machen.
- Deliverable: Onboarding-Flow (Institution-Auswahl + Verifizierung), Profil bearbeiten,
  Profilseite.

### Phase 3: Matching & Match Requests
- Goal: Relevante Vorschläge + Anfragen.
- Deliverable: Matching-Logik/-Datenmodell, Vorschlagsliste im Dashboard,
  Match-Request senden/annehmen/ablehnen.

### Phase 4: 1:1 Chat
- Goal: Echtzeit-Konversationen.
- Deliverable: Chat-Übersicht, 1:1 Chat mit Realtime.

### Phase 5: Mini Community
- Goal: Leichtgewichtiger Austausch.
- Deliverable: Posts (4 Typen) + Kommentare, ohne Likes/Feed-Algorithmus.

### Phase 6: Growth Foundation (abgeschlossen)
- Goal: Cold-Start lösen + internationales Auftreten.
- Deliverable: Zweisprachige Landing Page (EN/DE, Sprachumschalter, lokalisierte Routen, SEO),
  Referral-/Invite-System (Link, Copy/Share, Statistiken, Badges), "Dashboard niemals leer"
  (Match-Vorschläge + Profilfortschritt + Community-Preview + Invite-Modul),
  Entfernung aller Fake-Social-Proof-Elemente (Founding-Learners-Messaging stattdessen).

### Phase 7: Activation & Growth Analytics (abgeschlossen)
- Goal: Activation vor neuen Features. Fokus auf Aktivierung, Referral-Conversion und den ersten Match/Gespräch.
- Deliverable:
  - Funnel-Instrumentierung (Signup → Profil → Verifizierung → Erstes Match → Erstes Gespräch)
    über `analytics_events` und `src/lib/analytics.ts`.
  - Founder-Insights-Seite (`/insights`): KPI-Karten, Funnel-Visualisierung, Drop-off-Prozente,
    Referral-Performance und Einladungs-Conversion (read-only, intern).
  - Referral-Share-Optimierung: WhatsApp, Telegram, E-Mail (mailto) und native Share als First-Class-Flows.
  - Profil-Vervollständigungs-Führung mit klaren nächsten Schritten ("why it matters").
- Grundsatz: Keine zusätzlichen Produkt-Module. Nach dieser Phase Fokus auf Launch und erste echte Lernende.

## 7. Design System
- Farbrollen: background / primary (deep spruce green) / accent (warm honey) / secondary (warm stone) / foreground.
- Kein Blau, kein Violett.
- Typografie: Space Grotesk (Headings), Inter (Body).
- Cards: rounded-lg, Buttons: rounded-md, Pills: rounded-full. Keine harten Schatten.
- Dark Mode ist first-class: System-Erkennung + manueller Toggle, Persistenz, konsistente Tokens in allen Komponenten.

## 8. Phase 8: Launch Activation Hardening (abgeschlossen)

Leitprinzip: **Keine neuen Kernfeatures.** Nur Aktivierung, erste Gespräche, Netzwerkdichte,
Retention und Wachstum optimieren. Erfolg = mehr echte Konversationen zwischen Lernenden.

- **P1 — Verifizierung entkoppeln:** Verifizierung blockiert nie den Aktivierungspfad. Matching,
  Anfragen und Chat funktionieren unverifiziert. Verifizierte Profile erhalten einen
  Sichtbarkeits-Boost (+10 im Match-Score, neue Funktion `get_match_suggestions_v2`) und werden
  als Trust-/Erfolgs-Booster kommuniziert (Badge auf Karten, Hinweistext im Onboarding/Profil).
- **P2 — Cold-Start:** `get_match_suggestions_v2` bewertet zusätzlich Interessen-Überscheidung
  (+15) und liefert `shared_interests`. Reicht die Kohorte nicht für 3 Vorschläge, füllt eine
  ehrliche Founding-Fill-Karte das Grid — nie eine leere Match-Seite.
- **P3 — Time-to-Value:** Aktivierungs-Checkliste im Dashboard (Profil → erste Anfrage → erstes
  Gespräch → Verifizierung als Boost), abgeleitet aus echtem Nutzerzustand, nicht aus Fake-Fortschritt.
- **P4 — Conversation Activation:** Kontextbasierte Gesprächsstarter (gemeinsame Interessen,
  Fachbereich) beim Anfrage-Versand und im leeren Chat; geteilte Interessen werden hervorgehoben.
- **P5 — Retention (Stufe 1):** In-App Activity-Center (Pending-Anfragen + ungelesene Nachrichten,
  abgeleitet aus bestehenden Tabellen). Ungelesene Nachrichten werden beim Öffnen eines Chats als
  gelesen markiert. Stufe 2 (E-Mail: Antwort-Benachrichtigungen, wöchentliche Match-Empfehlungen,
  Community-Digest) folgt und benötigt Resend-Konfiguration.
- **P6 — Dark Mode first-class:** System-Erkennung, manueller Toggle in Sidebar + mobiler Leiste,
  Persistenz in `localStorage`, Initialisierung vor dem ersten Render (kein Flash), konsistente
  Kontrast-Regeln über die Token-Skalen.
- **P7 — Launch Readiness:** Kohorten-Checklisten für 10 / 50 / 100 Lernende (siehe Abschnitt 9).

### Phase 9: Onboarding-Friction, E-Mail-Retention & Campus-Dichte (abgeschlossen)
- Goal: Time-to-Value radikal senken, Retention-Stufe 2 (E-Mail First) starten und Kohorten messbar machen.
- Deliverable:
  - **P1 — Onboarding-Optimierung:** Onboarding von 3 auf **2 Schritte** reduziert (Schritt 1 „Über dich": Name/Fach/Niveau/Land, Schritt 2 „Studium & Ziele": Institution/Sprache/Zeitzone/Interessen/Ziele + optionale Verifizierung). **Live-Match-Preview** über `preview_match_count()` zeigt schon während des Ausfüllens, wie viele Lernende passen — inkl. Vornamen — plus „Matches warten auf dich"-Messaging. Value vor Arbeit.
  - **P2 — Retention Stufe 2 (Resend):** Edge Function `send-transactional-email` verschickt Welcome, Match-Anfrage erhalten, Match angenommen und neue Nachricht (Empfänger serverseitig aus der DB abgeleitet, dedupliziert über `email_log`, Rate-Limit bei Nachrichten: 1 E-Mail pro Conversation pro Stunde). Edge Function `weekly-match-digest` verschickt wöchentliche Match-Empfehlungen (aufrufbar durch Founder oder per Supabase-Cron). Nur transaktionale E-Mails, keine Newsletter/Automation.
  - **P3 — Campus-Dichte:** `get_founder_insights()` um `campus` erweitert (Lernende, Intra-Campus-Matches, Gespräche, aktive Lernende je Institution) und eigener Abschnitt „Campus-Dichte" in den Founder-Insights mit Aktivierungsdichte-Balken.
  - **E-Mail-Templates im Univers-Designsystem:** Alle transaktionalen E-Mails nutzen ein einheitliches Layout — warmes Off-White-Canvas, Tief-Tanne-Grün als Marke, Honig-Akzentlinie, akademische Serif-Überschriften, Sans-Body und internationaler Footer. Match-Anfrage und Match-Empfehlung enthalten echten akademischen Kontext (Studienfach + Institution), die Anfrage zusätzlich die persönliche Nachricht. Absender: `UniverS <hello@RESEND_FROM_DOMAIN>` (Domain zur Laufzeit aus dem Secret, kein Hardcoding).
- Grundsatz weiterhin: keine neuen Kernfeatures, keine Kurse/Jobs/Zertifikate/AI-Tutor.

## 10. Launch Readiness Checklist

### Kohorte 1 — 10 Lernende (Smoke Test)
- [ ] Alle 10 schließen Onboarding in < 3 Min ab (Timer im Founder-Funnel).
- [ ] Jede:r sieht sofort ≥ 3 Match-Vorschläge (Cold-Start-Fill greift, keine leere Seite).
- [ ] ≥ 1 Match-Anfrage pro Nutzer:in gesendet.
- [ ] ≥ 5 angenommene Anfragen → ≥ 5 echte Gespräche.
- [ ] Verifizierung optional getestet: 3 verifiziert, 7 nicht — alle können matchen und schreiben.
- [ ] Dark Mode (Desktop + Mobile): System, Toggle, Persistenz, keine Kontrastfehler.
- [ ] Icebreaker werden genutzt (`icebreaker_used` > 0).
- [ ] Founder-Insights zeigen alle Funnel-Events korrekt.
- **Exit:** ≥ 5 erste Konversationen, 0 leere Match-Ansichten, 0 Blocker.

### Kohorte 2 — 50 Lernende
- [ ] ≥ 1 Campus/Kohorte mit > 15 Nutzer:innen (Campus-Dichte messbar).
- [ ] > 30 % öffnen die App an ≥ 2 verschiedenen Tagen.
- [ ] Antwortrate auf Match-Anfragen > 50 %.
- [ ] > 70 % der neuen Nutzer:innen senden die erste Nachricht.
- [ ] Activity-Center wird geöffnet (Badge-Klick messbar).
- [ ] ≥ 10 Beitritte über Einladungslinks.
- [ ] Verifizierungsquote > 30 % (Ziel, kein Blocker).
- [ ] Keine offenen Bugs mit Severity high.
- **Exit:** Aktivierungsrate (Registrierung → erstes Gespräch) ≥ 40 %.

### Kohorte 3 — 100 Lernende
- [ ] Aktivierungsrate ≥ 50 %.
- [ ] Weekly Matched Conversations ≥ 25 pro Woche (Kernmetrik).
- [ ] Retention D7 ≥ 25 %.
- [ ] ≥ 3 aktive Campus-Cluster.
- [ ] ≥ 15 organische Community-Posts von Nutzer:innen (nicht Team).
- [ ] E-Mail-Retention (Stufe 2) aktiv: Antwort-Benachrichtigungen + wöchentliche Empfehlungen, Öffnungsrate > 25 %.
- [ ] Realtime-Chat stabil unter Last.
- [x] Impressum und Datenschutz erstellt (EN/DE, `/imprint` + `/privacy`, aus dem Footer verlinkt). **Vor Launch:** rechtliche Platzhalter (Name/Rechtsform/Adresse/Register/MWST) durch echte Angaben ersetzen und final juristisch prüfen lassen. AGB folgt erst mit kommerziellen Features.
- **Exit:** bereit für den öffentlichen Launch.

## 11. Phase 10: Technical SEO & Discoverability (abgeschlossen)

Ziel: Maximale Auffindbarkeit für universitätsbezogene Networking-, Study-Partner-,
Study-Buddy- und Student-Community-Suchanfragen. Keine neuen Kernfeatures.

- **Meta & Head:** `index.html` neu aufgebaut — learner-first Title/Description/Keywords,
  robots-Direktiven, Theme-Color, Favicon/Apple-Touch-Icon, vollständige Open-Graph- und
  Twitter-Card-Daten (inkl. og:image 1200×630). Render-blockierendes, ungenutztes Font entfernt.
- **SEO-Engine:** `src/lib/seo.ts` (canonical, hreflang, OG/Twitter, robots, JSON-LD-Injektion mit
  Aufräumen zwischen Routen) + `src/lib/schema.ts` (WebSite, Organization, EducationalOrganization,
  FAQPage, BreadcrumbList) + `src/hooks/useSeo.ts`.
- **Pro Seite:** Landing (indexierbar, JSON-LD + FAQ + hreflang en/de/x-default), Login/Signup
  (indexierbar, eigene Metas), `/app/*` und `/onboarding` (noindex,nofollow), 404 (noindex).
- **Sichtbare FAQ-Sektion** auf der Landing (6 Q&A, EN/DE) — liefert FAQPage-Schema und Trust.
- **Crawlability:** `public/robots.txt` (Disallow `/app`, `/onboarding`) und `public/sitemap.xml`
  mit hreflang-Alternates. Domain im Sitemap vor Launch ersetzen.
- **Core Web Vitals:** Fonts via `display=swap` + preconnect statt blockierendem `@import`,
  Hero-LCP-Bild mit `fetchPriority="high"`, feste Bildcontainer mit Aspect-Ratio (CLS-Schutz).

## 12. Phase 11: Legal Pages & Launch Readiness (abgeschlossen)

Ziel: Rechtliche Transparenz + Vertrauen vor dem ersten echten Nutzer. **Keine neuen Kernfeatures.**
SEO-Content-Hubs (Study-Partner-Landingpages) bewusst zurückgestellt — die ersten Nutzer kommen
aus direktem Outreach, Referrals und Communities, nicht aus organischer Suche.

- **Impressum (`/imprint`)** und **Datenschutzerklärung (`/privacy`)** erstellt — zweisprachig EN/DE,
  im Univers-Designsystem (Sticky-TOC, Karten-Sektionen, Anbieter-/Verarbeiter-Angaben).
  Datenschutz deckt DSG (Schweiz) + DSGVO ab: Datenkategorien, Zwecke/Rechtsgrundlagen,
  Auftragsverarbeiter (Supabase, Resend), Cookies/lokaler Speicher, transaktionale E-Mails,
  Aufbewahrung, internationale Übermittlung, Betroffenenrechte (inkl. Datenexport/Löschung), Altersgrenze 18+.
- **Korrektheitsprinzip:** Echte Angaben eingesetzt (Betreiber Abraham Isaq, Privatperson Schweiz,
  Baslerstrasse 39, 4665 Oftringen, Telefon 076 217 59 56, Marke UniverS,
  Website `https://getunivers.readdy.co`,
  Kontakt `hello@oloai.ch`, Verarbeiter Supabase/Resend). Es verbleiben **keine** rechtlichen
  Platzhalter mehr. Der Disclaimer „keine Rechtsberatung — final juristisch prüfen lassen" bleibt.
- **SEO:** Eigene Title/Description/Canonical pro Legal-Seite (`useSeo`), robots `index,follow`,
  in `public/sitemap.xml` aufgenommen.
- **Footer:** Alle toten `#top`-Anker der Rechts-Links ersetzt — Impressum/Datenschutz sind jetzt
  echte Routen (React Router `Link`), Sektions-Links nutzen lokalisierte Home-Pfade (`/en#...`)
  und funktionieren damit auch von Legal-Seiten aus. Hash-Scroll im Home-Handler ergänzt.
- **AGB/Terms:** bewusst noch nicht erstellt — erst sinnvoll, wenn Abos/Zahlungen/Marktplatz
  dazukommen. Footer-Link entfernt, bis die Seite existiert.
- **Nächster Schritt:** End-to-End Launch-Test (Signup → Bestätigung → Onboarding → Matching →
  Anfrage → Chat → Referral → E-Mail → Mobile → EN/DE), dann Publish und erste Lernende einladen.

## 13. Phase 12: Canonical Host Correction (abgeschlossen)

**Korrektur:** `https://oloai.ch` wurde zunächst als kanonische Produktions-URL gesetzt. Bei der
Verifikation stellte sich heraus, dass **`oloai.ch` aktuell ein völlig anderes Produkt ausliefert**
(eine separate Anwendung „OLO AI — AI Operating System for Swiss SMEs", eigenes Readdy-Projekt),
**nicht UniverS**. Die echte UniverS-Produktion läuft auf `https://getunivers.readdy.co`.
Auth-Redirects und Canonicals dürfen daher **nicht** auf `oloai.ch` zeigen — sonst landen
Bestätigungs-/Reset-Mails und Suchmaschinen im falschen Produkt.

**Aktuelle Single Source of Truth: `https://getunivers.readdy.co`.** Eine Custom-Domain-Umstellung
(inkl. OG-Image-Hosting, Sitemap-Submission, Indexing, Auth-Redirects) erfolgt erst, wenn die Domain
tatsächlich UniverS ausliefert.

- **Single Source of Truth:** `CANONICAL_ORIGIN = 'https://getunivers.readdy.co'` in `src/lib/seo.ts`.
  `siteBase()` leitet Canonical, hreflang-Alternates und `og:url` ausschließlich daraus ab — nie aus
  `window.location.origin` (das würde auf Preview-Hosts falsche Canonicals erzeugen).
- **Head (`index.html`):** Canonical + `og:url` auf `https://getunivers.readdy.co` korrigiert;
  Title/Description/Keywords auf breite Learner-Positionierung (`study partner`, `study buddy`,
  `learning community`, `student networking`, `academic networking`, `study groups`).
- **Sitemap/Robots:** `public/sitemap.xml` und `public/robots.txt` referenzieren ausschließlich
  `https://getunivers.readdy.co` (hreflang-Alternates inklusive).
- **Structured Data:** `schema.ts` — Organization/WebSite/EducationalOrganization leiten ihre URLs aus
  `siteBase()` ab (somit korrekter Host); Fake-`sameAs` entfernt, Logo + `email` + `PostalAddress` gesetzt.
- **E-Mail-Deep-Links:** `send-transactional-email` und `weekly-match-digest` erzeugen ihre Links aus
  `SITE_ORIGIN` (`https://getunivers.readdy.co`, env-override `PUBLIC_SITE_URL`) statt aus dem
  `Origin`-Request-Header — Bestätigungs-, Match-, Chat- und Digest-Links landen garantiert auf der echten App.
- **Auth-Redirects:** Login/Signup/Google/Reset nutzen `${window.location.origin}/...` → auf der echten
  Domain identisch mit Produktion. **Supabase-Konsole bleibt vorerst auf** Site URL
  `https://getunivers.readdy.co` und Redirect-Allow-List `.../app`, `.../onboarding`,
  `.../reset-password` — **nicht** auf `oloai.ch` umstellen.
- **Korrekt implementiert (bleibt gültig):** Passwort-Reset-Flow (vorher nicht vorhanden),
  Homepage-Copy-Feinschliff, strukturierte Daten, robots/sitemap-Struktur.
- **Offen für später:** Custom-Domain auf UniverS umziehen → dann `CANONICAL_ORIGIN`, `SITE_ORIGIN`,
  sitemap/robots und Supabase-Auth in einem Zug auf die neue Domain umstellen; OG-Image/Logo auf der
  Domain hosten; Social-Caches (LinkedIn/WhatsApp/Telegram) flushen.

## 16. Phase 15: Learner-first Word Alignment (abgeschlossen)

Ziel: UniverS nirgends als reines „University"-Produkt lesen. „Learners" ist der Default-Begriff;
Universit\u00e4t ist nur eine von mehreren Zielgruppen (School students 18+, University students, Exchange
students, Alumni, Mentors, Lifelong learners). Keine neuen Features.

- **Positionierungs-Sprache entsch\u00e4rft:** „academic networking platform" → „learning network",
  „akademische Netzwerk-Plattform" → „Lernnetzwerk" — in Landing-SEO (EN/DE), FAQ („What is
  UniverS?"), `EducationalOrganization`-JSON-LD (EN/DE) und Landing-Keywords.
- **Institutions-Band:** Titel „Built for the global academic network" → „Built for learners
  worldwide" / „Gebaut f\u00fcr Lernende weltweit".
- **OG/Twitter-Bild:** Prompt von „university students" auf „adult learners" umgestellt
  (`src/lib/seo.ts` + `index.html`).
- **Keywords:** `student networking, academic networking` → `learner networking`.
- **Bewusst beibehalten:** die Zielgruppen-Aufz\u00e4hlungen (School/University/Exchange/Alumni/Mentor/
  Lifelong learners) und die Sektion „A learning network, not just a university network" — sie
  benennen die Zielgruppen korrekt und grenzen UniverS gerade von „university-only" ab.

## 15. Phase 14: Who-it's-for Section & 18+ Policy Confirmation (abgeschlossen)

Ziel: Die breitere Learner-Positionierung sichtbar machen, ohne neue Kernfeatures. Zusätzlich die in
Phase 13 offene Altersfrage verbindlich entscheiden.

- **Neue Landing-Sektion „Who it's for" / „Für wen":** Neuer Abschnitt zwischen `InstitutionsBand`
  und `HowItWorks` (`src/pages/home/components/WhoItsFor.tsx`, eingebunden in `page.tsx`,
  Anker `#who-its-for`).
  - Eyebrow „Who it's for" / „Für wen", Titel **„A learning network, not just a university network"**
    / „Ein Lernnetzwerk — nicht nur ein Uni-Netzwerk".
  - 6 Karten (konsistentes Designsystem, abwechselnde primary/accent/secondary-Töne, Remix-Icons):
    School students, University students, Exchange students, Alumni, Mentors, Lifelong learners —
    jeweils mit Beschreibung, die den Kreis bewusst breit hält.
  - Abschließender Hinweis-Block mit der Altersklausel: „UniverS is intended for learners aged 18 and
    older." / „UniverS richtet sich an Lernende ab 18 Jahren."
- **Alterspolitik bestätigt: 18+ bleibt.** Keine Minderjährigen, keine Eltern-Einwilligung, keine
  zusätzlichen Compliance-Aufwände in dieser Phase. „School students" wird konsistent als erwachsene
  Lernende erklärt (Berufs-/Nachholbildung, Weiterbildung, mature students) — sowohl in der Sektion
  als auch in der Datenschutzerklärung (`/privacy`, EN/DE).
- **Copy (EN/DE):** Neue `landing.audience.*`-Keys in `src/i18n/local/en/common.ts` und
  `src/i18n/local/de/common.ts`.
- **Unverändert:** Keine SEO-Hubs, keine öffentlichen Profile, keine neuen Community-Systeme,
  keine neuen Onboarding-Flows, keine AI-Features.
- **Nächster Schritt:** Publish (User-Aktion) → End-to-End-Validierung mit echten Postfächern
  (Signup → E-Mail-Bestätigung → Onboarding → Match-Anfrage → Annahme → Chat → E-Mail-Trigger),
  danach `email_log`, Notification-Badges und Zustellung prüfen.

## 14. Phase 13: Audience Broadening (abgeschlossen)

Ziel: UniverS darf **nicht** als reine „University-only"-Plattform positioniert werden. Die Plattform
richtet sich an **Lernende jeder Stufe**: Schüler:innen, Studierende, Austauschstudierende, Alumni,
Mentor:innen und lebenslang Lernende. Mission bleibt: vertrauenswürdige Lernpartner und bedeutungsvolle
akademische Verbindungen. Akademische Identität bleibt stark, aber der Kreis ist breiter (Schulen,
Universitäten, Akademien, Lernorganisationen).

- **Head (`index.html`):** Title `Find a Study Partner & Your Learning Community | UniverS`;
  Description und Twitter-/OG-Texte auf „verified learners worldwide — students, alumni and mentors"
  umgestellt; Keywords `university students` → `learning community`; alle `og:image:alt` von
  „at university" befreit.
- **SEO-Engine & Schema:** `OG_IMAGE_ALT` (`seo.ts`) verallgemeinert; Organization- und
  EducationalOrganization-Beschreibungen (EN/DE) nennen jetzt explizit School/University/Exchange/
  Alumni/Mentor statt nur „university students".
- **Landing-Copy (EN/DE):** Hero-Badge „For learners at every stage" / „Für Lernende auf jeder Stufe",
  Hero-Text mit allen Zielgruppen, FAQ-Antworten verallgemeinert (z. B. „Is UniverS free?" statt
  „free for students?"), Waitlist-Bullets um Austauschstudierende erweitert, App-SEO-Descriptions
  (Login/Signup/Community) entkoppelt.
- **Legal:** Impressum-Description und Altersklausel („learners aged 18 and older") verallgemeinert.
  **Altersfrage — entschieden in Phase 14:** Die Altersgrenze bleibt bei **18+**. „School students"
  wird ausdrücklich als erwachsene Lernende interpretiert (Berufsbildung, Nachholbildung,
  Weiterbildung, mature students). Keine Minderjährigen, keine Eltern-Einwilligung, keine
  zusätzlichen Compliance-Pflichten in dieser Phase.
- **Nicht geändert:** Institutionstypen (`School / University / Academy / Learning Organization`),
  Rollen-Listen im Onboarding, Footer-Links — waren bereits breit aufgestellt.

## 17. Phase 15: Final Interaction Audit (abgeschlossen)

Ziel: Vor Launch keine Fake-Interaktionen. **Regel:** Sieht ein Element klickbar aus, muss es eine
sinnvolle Aktion ausführen. Keine Platzhalter-Links, keine toten UI-Elemente.

- **Soziale Icons entfernt:** Die vier Platzhalter-Icons (X, LinkedIn, Discord, Instagram) zeigten
  alle auf `#top`. Da noch **keine offiziellen Profile existieren**, wurden sie komplett entfernt
  (inkl. `SOCIALS`-Konstante und `landing.footer.social`-Key in EN/DE). Entschieden: keine sichtbaren
  Icons ohne Ziel — lieber keine Icons. Sobald echte Profile existieren, mit echten URLs zurück.
- **Footer → For learners:** Spalte von 3 auf **6 Einträge** erweitert (School students, University
  students, Exchange students, Alumni, Mentors, Lifelong learners / DE analog) und alle auf die neue
  Sektion `#who-its-for` verlinkt (vorher zeigten sie fälschlich auf `#global`).
  `columnTargets` in `SiteFooter.tsx` angepasst.
- **Footer → Product:** Bereits korrekt — How it works → `#how-it-works`, Features → `#features`,
  Community → `#community`. Alle drei lösen zu echten Sektionen auf, keine Änderung nötig.
- **Worldwide cards (School / University / Academy / Learning Organization):** Bereits sauber — die
  Karten in `GlobalFields.tsx` sind nicht-interaktive Divs ohne Hover-State, ohne `cursor-pointer`,
  ohne Click-Handler. Sie lesen sich als informative Chips, nicht als Buttons. Keine Änderung nötig.
- **Zusätzlicher Sweep:** Navbar-Logo (`#top` → Hero-Sektion) und alle Nav-Links
  (`#how-it-works`, `#features`, `#global`, `#community`, `#faq`) geprüft — alle zeigen auf echte
  Sektionen. Keine toten Anker mehr im Marketing-Bereich.
- **Nächster Schritt:** Publish (User-Aktion) → End-to-End-Validierung mit echten Postfächern.

## 18. Phase 16: Landing Focus & Simplification (abgeschlossen)

Ziel: Die Landing so ruhig und fokussiert wie die Mission machen — **weniger Sektionen, weniger
Scrollen, keine konkurrierenden Botschaften**. Kein TikTok-, Instagram-, Kurs-Marktplatz- oder
SaaS-Gefühl. Keine neuen Features.

- **Struktur von 11 auf 5 Sektionen reduziert:**
  1. **Hero** — Headline „Find the right study partner." / „Finde den richtigen Lernpartner.",
     Subline „Connect with learners, start meaningful conversations, share knowledge and learn
     together.", ein Primary CTA („Create Free Account") + leiser Sign-in-Link. Trust-Liste und
     „How it works"-Sekundärbutton aus dem Hero entfernt.
  2. **What do you want to learn?** (neu, `LearnGoals.tsx`, Anker `#learn`) — vier interaktive
     Karten (Exam preparation, Language exchange, Study & continuing education, Find a mentor or
     study partner); jede führt direkt zu `/signup`.
  3. **How it works** — auf **4 Schritte** gekürzt: Create your profile → Find compatible learners
     → Start a conversation → Learn together.
  4. **Trust & Safety** (neu, `TrustSafety.tsx`, Anker `#trust`) — Verified learners, Privacy-first,
     Meaningful connections, 18+ community.
  5. **Final CTA** — „Find a study partner today." mit einem einzigen CTA.
- **Entfernt (REMOVE):** `InstitutionsBand` (geborgte Glaubwürdigkeit durch Logo-Reihe),
  `Features` (SaaS-Feature-Grid), `GlobalFields` (dunkle Coverage-Spec-Sheet), `Stats`
  (Plattform-Metrik-Prahlerei), `CommunityPreview` (Feed-Keim), `FoundingLearners`
  (Pre-Launch-/Founding-Messaging), `Faq` (erklärt, was ein conversation-first Produkt ohnehin
  beantwortet). Dateien gelöscht.
- **WhoItsFor (REMOVE):** Zielgruppen-Karten entfernt; die Zielgruppe wird jetzt implizit über
  „learners at every stage" und die Trust-Sektion abgedeckt.
- **SEO angepasst:** FAQPage-JSON-LD entfernt (Schema muss zu sichtbarem Inhalt passen — es gibt
  keine FAQ-Sektion mehr); `LocalizedLanding` liefert nur noch WebSite / Organization /
  EducationalOrganization.
- **Navigation & Footer neu verdrahtet:** Navbar-Links jetzt „What you can learn" (`#learn`),
  „How it works" (`#how-it-works`), „Trust & safety" (`#trust`). Footer-Spalten (EN/DE) auf die
  lebenden Anker umgestellt (Product → learn/how-it-works/trust, For learners → learn).
- **i18n (EN/DE) bereinigt:** alte Keys (`landing.features/stats/global/community/founding/faq/
  audience/institutions/hero.trust/hero.ctaHow`) entfernt; neue Keys (`landing.learn.*`,
  `landing.trust.*`, `landing.hero.signIn`) ergänzt.
- **Bewusst beibehalten:** Hero-Bild + schwebende Match-Karte (zeigt Menschen), das Zweisprachen-Setup
  (EN/DE), das Designsystem (primary/accent/secondary-Töne).
- **Nächster Schritt:** Publish (User-Aktion) → „10-Sekunden-Test": Versteht ein neuer Besucher
  sofort, dass UniverS Lernpartner vermittelt?

## 19. Phase 17: One-Screen Landing & Registration-First (abgeschlossen)

Ziel: Die Landing auf das **Einfachheitsniveau eines Login-Screens** bringen (Referenz: Instagram-Login
— ein Screen, keine Scroll-Pflicht, Formular sofort sichtbar). **Kein** Instagram-Kopieren, **keine**
Social-Media-Mechanik (keine Reels, Follower, Likes, Content-Feeds), **keine** Marketing-Sprache,
**keine** Corporate-/Kurs-/SaaS-Anmutung. Ziel bleibt die ruhige Mission:
*Find a study partner → Start a conversation → Share knowledge → Learn together.* Keine neuen Features.

- **Struktur (7 Elemente, ein Screen):** 1. UniverS-Logo, 2. eine Headline („Find the right study
  partner."), 3. eine Kurzbeschreibung, 4. vier Lernpfade, 5. **Registrierungsformular direkt sichtbar**,
  6. kompakte Trust-Zeile, 7. ruhiger Final-CTA. Split-Layout (Desktop): links Botschaft + Pfade +
  Trust, rechts das Formular — kein Scrollen nötig.
- **Registrierung direkt auf der Landing:** Neues `RegistrationPanel.tsx` (Supabase-Auth: Name, E-Mail,
  Passwort, Google, E-Mail-Bestätigungszustand mit Resend). Kein Zwischenschritt mehr von „neugierig"
  zu „Konto angelegt". Lernpfad-Klick setzt das Ziel, markiert es im Formular und fokussiert es
  (Ziel wird als `goal` in die Signup-Metadaten geschrieben). `/signup` bleibt als Route bestehen.
- **KEEP:** Hero (umgebaut), die 4 Lernpfade, Trust-Punkte, ein Final-CTA.
- **SIMPLIFY:** How-it-works → entfernt; Trust → eine kompakte Zeile; Footer → minimal.
- **REMOVE:** Top-Navbar, 4-Schritte-Sektion, großes Hero-Bild, 3-Spalten-Footer,
  „Weiter zur Registrierung"-Buttons, zweiter Hero-Button. Gelöschte Dateien: `SiteNavbar.tsx`,
  `LearnGoals.tsx`, `HowItWorks.tsx`, `TrustSafety.tsx`, `StartCTA.tsx`.
- **Navigation → ein Logo:** Header enthält nur noch Logo + Sprachumschalter + „Log in" (kein
  Link-Menü). **Neue zentrale `BrandLogo.tsx`** (tone/size-Varianten) und überall eingesetzt:
  Landing, Footer, Auth/Reset, Onboarding, App-Shell, Legal-Header — ein konsistentes Logo.
- **Copy (EN/DE) neu:** `landing.header/hero/paths/register/trust/cta/footer` (kompakte Keys),
  `landing.nav/learn/howItWorks` sowie Mehrspalten-Footer und Marketing-Floskeln entfernt.
  Trust-Wording: 18+ learners · Privacy-first · Meaningful conversations · Verified learners.
- **SEO unverändert schlank:** Landing bleibt indexierbar; FAQ-Schema bereits entfernt (Phase 16);
  Keywords unverändert (`study partner`, `learning community`, `learner networking`).
- **Bewusst NICHT:** Bio-/Feed-Elemente, Follower/Likes, Kurs-Marktplatz, Video/Reels,
  zusätzliche Buttons oder Sektionen.
- **Nächster Schritt:** Publish (User-Aktion) → 5–10-Sekunden-Test: Versteht ein neuer Besucher
  sofort, was UniverS ist, und kann er/sie ohne Scrollen ein Konto anlegen?

## 20. Phase 18: Dark Hero Image & CTA Consolidation (abgeschlossen)

Ziel: Die Landing bekommt ein **echtes, erzählendes Hero-Visual** (Lernende, die gemeinsam lernen)
statt einer generischen Illustration — verbunden mit der ruhigen UniverS-Anmutung und **weniger
konkurrierenden Signup-Aktionen**. Keine neuen Features.

- **Hero-Bild:** Das vom Nutzer gelieferte Bild (vier Lernende am Tisch mit Laptop, Notizen und
  Kaffee, warmes dunkles Licht) wird als **full-bleed Hintergrund** des Heros eingesetzt. Der
  eingebrannte Text/Logo/Button im Bild wurde per Bildbearbeitung entfernt, damit die echte
  HTML-Headline sauber darüber liegt (kein Doppeltext). Dunkles, links-lastiges Gradient-Overlay
  für Lesbarkeit; Menschen rechts sichtbar.
- **Hero-Struktur neu:** Vierzeilige Headline
  *Find the right study partner. / Start a conversation. / Share knowledge. / Learn together.*
  (Zeile 2 und 4 im grünen Primary-Ton), Subline
  *Connect with learners and students who share your field, interests and academic goals.*,
  ein einziger CTA („Find your partner", scrollt zur Registrierung) plus die ruhige Trust-Zeile.
- **Audience-Wording:** Bewusst „learners **and** students" (nicht „university students") — im
  Einklang mit Phase 15 („learners" ist der Default-Begriff).
- **Kürzung nach unten:** Der komplette untere „Create Free Account"-Banner (`FinalCTA.tsx`) wurde
  **entfernt** — die Seite hat bereits genug Signup-Aktionen (Hero-CTA + Formular). Keine
  doppelten CTA-Sektionen mehr.
- **Ein Signup-Bereich:** Neues `RegisterSection.tsx` bündelt „What do you want to learn?"
  (`GoalPaths`) und das `RegistrationPanel` in einer Zone (Anker `#register`). Das Formular bleibt
  direkt sichtbar; Zielauswahl setzt `goal` und fokussiert das Formular.
- **Dark-Header:** Header liegt jetzt **auf** dem dunklen Hero (Logo `tone="dark"`,
  `LanguageSwitcher` mit neuer `tone`-Prop für hell-auf-dunkel, „Log in" hell). Premium-Anmutung.
- **Code-Aufräumung:** `landing.hero.title1/titleAccent/title2` → `line1..line4` + `cta`;
  `landing.paths.hint` ergänzt; `landing.cta.*` entfernt (EN/DE). `FinalCTA.tsx` gelöscht,
  `page.tsx` verdrahtet Hero/Register/Footer neu.
- **Bewusst NICHT:** Social-Mechanik, Feed, Kurs-Marktplatz, SaaS-Muster, zusätzliche Sektionen.
- **Nächster Schritt:** Publish (User-Aktion) → prüfen, ob das Hero-Bild auf Mobil und Desktop
  sauber zuschneidet (Text gut lesbar, Lernende sichtbar).

## 21. Phase 19: SEO Readiness Audit & Domain Migration Decision (Audit abgeschlossen, Migration offen)

Anlass: Nutzer meldete „UniverS läuft jetzt auf https://oloai.ch" und bat um ein vollständiges
Google-Search-Console-/SEO-Readiness-Audit mit `oloai.ch` als einziger Produktionsdomain.

**Ergebnis der Live-Verifikation:** `https://oloai.ch` liefert weiterhin das **andere Produkt**
(„OLO AI — The AI Operating System for Swiss SMEs", eigenes Readdy-Projekt). Belegt durch:
- `<title>` = „OLO AI …", `og:site_name` = „OLO AI"
- `oloai.ch/sitemap.xml` listet `/de|en|fr/build`, `/impressum`, `/datenschutz`, `/kontakt`
- `oloai.ch/robots.txt` gehört ebenfalls zu OLO AI
UniverS-Routen (`/en`, `/de`, `/signup`, `/login`, `/imprint`, `/privacy`) sind auf der Domain
**nicht** vorhanden. Damit gilt die Korrektur aus Phase 12 weiterhin.

**Audit-Ergebnis (Ist-Zustand):**
- Canonical / hreflang / `og:url`: konsistent auf **einen** Host — `https://getunivers.readdy.co`
  (`CANONICAL_ORIGIN` in `src/lib/seo.ts`). ✅
- Open Graph + Twitter Card: vollständig (`og:type/site_name/url/title/description/image 1200×630/
  image:alt/locale + alternate`, `twitter:card`). ✅
- Structured Data: WebSite + Organization + EducationalOrganization auf der Landing. ✅
- Auth-Links (Login/Signup/Reset/Google): aus `window.location.origin` gebaut — **kein Hardcoding**,
  self-correcting auf den ausliefernden Host. ✅
- Sitemap/Robots: vorhanden und korrekt, referenzieren `https://getunivers.readdy.co`. ✅
  (Live unter `oloai.ch/…` noch **nicht** erreichbar, weil dort OLO AI ausliefert.) ⚠️
- E-Mail-Deep-Links: `send-transactional-email` + `weekly-match-digest` pinnen `SITE_ORIGIN` auf
  `getunivers.readdy.co` (env-override `PUBLIC_SITE_URL`). ✅
- Legal-Seiten „Website"-Feld: Text nennt `https://getunivers.readdy.co`. ✅
- Blockierend wäre **nur** ein vorschneller Switch der Canonicals auf `oloai.ch` → Duplicate-Canonical
  gegenüber einem fremden Produkt → Deindexing-Risiko. Deshalb **nicht** durchgeführt.

**Entscheidung (vom Nutzer bestätigt):**
`https://getunivers.readdy.co` bleibt Source of Truth, bis UniverS tatsächlich auf `oloai.ch`
deployed und verifiziert ist. **Keine Code-Änderung in dieser Phase.**

**Domain-Ownership / Search Console (bestätigt):**
- `oloai.ch` gehört dem Nutzer und ist in **Google Search Console bereits verifiziert** (Property
  vorhanden). Das ist die Voraussetzung für die spätere Migration.
- Hinweis: Solange `oloai.ch` das fremde Produkt (OLO AI) ausliefert, indexiert diese GSC-Property
  faktisch OLO AI. Nach dem UniverS-Deploy wird im gleichen `oloai.ch`-Property die
  UniverS-`sitemap.xml` eingereicht und die Indexierung für UniverS geprüft.

**Verbindliche Migrations-Reihenfolge (erst nach Live-Deploy + Verifikation):**
1. UniverS deployen und auf `oloai.ch` verifizieren
2. End-to-End prüfen: Landing, Signup, Login, Onboarding, Matching, Chat, E-Mail-Bestätigung,
   Passwort-Reset
3. Canonicals umstellen (`CANONICAL_ORIGIN`)
4. hreflang-Alternates umstellen (leiten aus `siteBase()` ab — automatisch mit)
5. `sitemap.xml` umstellen (+ im `oloai.ch`-GSC-Property einreichen)
6. `robots.txt` umstellen
7. Structured Data (WebSite / Organization / EducationalOrganization — leiten aus `siteBase()` ab,
   automatisch mit; Werte gegen sichtbaren Inhalt prüfen)
8. Auth-Konfiguration (Supabase Site URL + Redirect-Allow-List: `/app`, `/onboarding`,
   `/reset-password`)
9. E-Mail-Links (`SITE_ORIGIN`, ggf. via `PUBLIC_SITE_URL`)
10. **Zuletzt:** 301-Redirects von `getunivers.readdy.co` → `oloai.ch`

Alle Umschaltpunkte (Canonical, hreflang, Sitemap, robots.txt, Structured Data, Auth-URLs,
E-Mail-Links) hängen an genau diesen Stellen: `CANONICAL_ORIGIN` (`src/lib/seo.ts`), `SITE_ORIGIN`
(`supabase/functions/*`), der **Readdy-SEO-Generator** (der `sitemap.xml` + `robots.txt` erzeugt und
ausliefert) — plus der Supabase-Konsole.
Damit ist der Umzug ein einzelner, koordinierter Schritt.

Ziel: **genau eine** kanonische Domain. Zusätzlich beim Umzug: OG-Image/Logo auf der Domain hosten und
Social-Caches (LinkedIn/WhatsApp/Telegram) flushen.

## 22. Phase 20: Sitemap/Robots Ownership → Platform SEO Engine (abgeschlossen)

Anlass: Google Search Console meldete „Sitemap could not be read". Der Nutzer sah unter
`https://getunivers.readdy.co/sitemap.xml` nur die **nackten URLs, Zeitstempel und Prioritäten** —
**keine** XML-Tags, kein XML-Header, keine Baum-Ansicht.

**Diagnose (Live-Verifikation der ausgelieferten Antwort):**
- Die Antwort enthielt `<?xml version="1.0" …?>` **nicht**, alle Attribut-Anführungszeichen waren
  entfernt (`xmlns=http://…`, `rel=alternate`, `href=https://…`) und selbst-schließende Tags waren in
  verschachtelte Schluss-Tags umgeschrieben. Das ist die Signatur eines **HTML-Parsers**, der XML als
  HTML interpretiert (XML-Deklaration → verworfen, unbekannte Tags → verschluckt, Whitespace → kollabiert).
- Folge: Google findet `<urlset>` nicht → „Sitemap could not be read". Genau deckungsgleich mit dem,
  was der Nutzer im Browser sieht.
- Der ausgelieferte Inhalt war zudem **nicht** die handgepflegte Datei (Voll-Zeitstempel
  `2026-09-20T21:56:18.435Z` statt `2026-09-20`) → **die Plattform regeneriert die Datei beim Publish**
  und liefert ihre eigene Version aus.
- **Der Dateiinhalt war nie das Problem** — Problem war der `Content-Type` auf dem Auslieferungsweg,
  der von der Hosting-Ebene (nicht von App-Code) bestimmt wird.

**Entscheidung (vom Nutzer bestätigt): Der Plattform-Engine nicht entgegenarbeiten.**
- `public/sitemap.xml` und `public/robots.txt` wurden **gelöscht**. Sie haben die
  Plattform-Versionen überschattet und waren die Ursache der falschen Auslieferung.
- **Readdy SEO-Generator ist ab jetzt die einzige Quelle der Wahrheit** für `sitemap.xml` + `robots.txt`.
  Keine manuell gepflegten Duplikate mehr im Repo.
- Republish über die Plattform ist erforderlich, damit die Plattform-Versionen allein ausgeliefert werden.

**Nicht geändert (bewusst):** Canonicals, Domains, Auth-URLs, Structured Data, Canonical-Host.
`https://getunivers.readdy.co` bleibt weiterhin Source of Truth (siehe Phase 12 / Phase 19).

**Übergabeschritte an den Nutzer:**
1. SEO Settings öffnen → `sitemap.xml` / `robots.txt` generieren.
2. Site republishen.
3. Prüfen, dass `…/sitemap.xml` und `…/robots.txt` die Plattform-Versionen sind.
4. In GSC die fehlgeschlagene Sitemap entfernen, `sitemap.xml` neu einreichen, auf „Success" prüfen.

**Nächster Produktfokus (nach gesunder Sitemap):** Nicht Indexierung, sondern die Kernmetrik.
End-to-End-Kette **Signup → E-Mail-Bestätigung → Onboarding → Match-Anfrage → Match-Annahme →
erstes Gespräch** validieren. Erfolg = Lernende finden Lernpartner und starten echte Gespräche.